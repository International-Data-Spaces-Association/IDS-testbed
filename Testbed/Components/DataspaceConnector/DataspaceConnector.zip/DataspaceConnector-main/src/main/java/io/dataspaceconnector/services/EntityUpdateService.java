/*
 * Copyright 2020 Fraunhofer Institute for Software and Systems Engineering
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.dataspaceconnector.services;

import java.net.URI;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import de.fraunhofer.iais.eis.Artifact;
import de.fraunhofer.iais.eis.Representation;
import de.fraunhofer.iais.eis.Resource;
import io.dataspaceconnector.exceptions.ResourceNotFoundException;
import io.dataspaceconnector.model.Agreement;
import io.dataspaceconnector.services.ids.updater.ArtifactUpdater;
import io.dataspaceconnector.services.ids.updater.RepresentationUpdater;
import io.dataspaceconnector.services.ids.updater.RequestedResourceUpdater;
import io.dataspaceconnector.services.resources.AgreementService;
import io.dataspaceconnector.services.resources.ArtifactService;
import io.dataspaceconnector.services.resources.RelationServices;
import io.dataspaceconnector.utils.ErrorMessages;
import io.dataspaceconnector.utils.SelfLinkHelper;
import io.dataspaceconnector.utils.Utils;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

/**
 * This service offers method for updating entities.
 */
@Log4j2
@Service
@RequiredArgsConstructor
public class EntityUpdateService {

    /**
     * Updates a requested resource by using an ids resource.
     */
    private final @NonNull RequestedResourceUpdater requestedResourceUpdater;

    /**
     * Updates a representation by using an ids representations.
     */
    private final @NonNull RepresentationUpdater representationUpdater;

    /**
     * Updates an artifact by using an ids artifacts.
     */
    private final @NonNull ArtifactUpdater artifactUpdater;

    /**
     * Service for agreements.
     */
    private final @NonNull AgreementService agreementService;

    /**
     * Service for linking artifacts to agreement.
     */
    private final @NonNull RelationServices.AgreementArtifactLinker agreementArtifactLinker;

    /**
     * Service for artifacts.
     */
    private final @NonNull ArtifactService artifactService;

    /**
     * Update database resource.
     *
     * @param resource The ids resource.
     */
    public void updateResource(final Resource resource) {
        try {
            final var updated = requestedResourceUpdater.update(resource);
            if (log.isDebugEnabled()) {
                log.debug("Updated resource. [uri=({})]", SelfLinkHelper.getSelfLink(updated));
            }

            final var representations = resource.getRepresentation();
            for (final var representation : Utils
                    .requireNonNull(representations, ErrorMessages.LIST_NULL)) {
                updateRepresentation(representation);
            }
        } catch (ResourceNotFoundException | IllegalArgumentException exception) {
            if (log.isDebugEnabled()) {
                log.debug("Failed to update resource. [uri=({})]", resource.getId());
            }
        }
    }

    /**
     * Update database representation that is known to the consumer.
     *
     * @param representation The ids representation.
     */
    public void updateRepresentation(final Representation representation) {
        try {
            final var updated = representationUpdater.update(representation);
            if (log.isDebugEnabled()) {
                log.debug("Updated representation. [uri=({})]",
                        SelfLinkHelper.getSelfLink(updated));
            }

            final var artifacts = representation.getInstance();
            for (final var artifact : Utils.requireNonNull(artifacts, ErrorMessages.LIST_NULL)) {
                updateArtifact((Artifact) artifact);
            }
        } catch (ResourceNotFoundException | IllegalArgumentException exception) {
            if (log.isDebugEnabled()) {
                log.debug("Failed to update representation. [uri=({})]", representation.getId());
            }
        }
    }

    /**
     * Update database artifact that is known to the consumer.
     *
     * @param artifact The ids artifact.
     */
    public void updateArtifact(final Artifact artifact) {
        try {
            final var updated = artifactUpdater.update(artifact);
            if (log.isDebugEnabled()) {
                log.debug("Updated artifact. [uri=({})]", SelfLinkHelper.getSelfLink(updated));
            }
        } catch (ResourceNotFoundException exception) {
            if (log.isDebugEnabled()) {
                log.debug("Failed to update artifact. [uri=({})]", artifact.getId());
            }
        }
    }

    /**
     * Set confirmed boolean to true.
     *
     * @param agreement The database agreement.
     * @return true if the agreement has been confirmed.
     */
    public boolean confirmAgreement(final Agreement agreement) {
        try {
            return agreementService.confirmAgreement(agreement);
        } catch (ResourceNotFoundException exception) {
            if (log.isDebugEnabled()) {
                log.debug("Failed to confirm agreement. [uri=({})]", agreement.getId());
            }

            return false;
        }
    }

    /**
     * Link list of artifacts to a contract agreement.
     *
     * @param artifactIds List of artifact ids.
     * @param agreementId The id of the agreement.
     */
    public final void linkArtifactToAgreement(final List<URI> artifactIds, final UUID agreementId) {
        final var localArtifacts = Utils.toStream(artifactIds)
                .map(x -> artifactService.identifyByRemoteId(x).get()).collect(Collectors.toSet());
        agreementArtifactLinker.add(agreementId, localArtifacts);
    }
}
