export class Result {
  public successful: boolean;
  public message: string;
}
