export class IncomingConnection {
  public endpointIdentifier: string;
  public attestationResult: string;
  public connectionKey: string;
  public remoteHostName: string;
}
