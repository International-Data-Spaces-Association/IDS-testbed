The _ids-settings_ module contains the Settings Component, responsible for interfacing an internal database to store and retrieve Connector configuration data.  
