The _ids-dataflow-control_ module contains the LUCON policy engine and all necessary interfacing components (PDP). It takes care of the execution of prolog formula sets.
