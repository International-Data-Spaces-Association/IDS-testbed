The _ids-api_ module contains all interface definitions. This includes internal interfaces (inside modules), external interfaces (between bundles) and used protobuf-interfaces as well. 
