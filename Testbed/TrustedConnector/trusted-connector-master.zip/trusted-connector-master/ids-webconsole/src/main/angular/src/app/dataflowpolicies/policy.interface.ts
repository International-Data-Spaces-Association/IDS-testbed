export interface Policy {
  policyName: string;
  policyDescription: string;
}
