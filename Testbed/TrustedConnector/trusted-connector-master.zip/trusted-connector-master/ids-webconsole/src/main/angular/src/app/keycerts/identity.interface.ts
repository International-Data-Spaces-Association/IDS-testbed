export interface Identity {
    cn: string;
    ou: string;
    o: string;
    l: string;
    s: string;
    c: string;
}
