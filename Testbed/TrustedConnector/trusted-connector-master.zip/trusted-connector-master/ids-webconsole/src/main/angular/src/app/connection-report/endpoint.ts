export class Endpoint {
  public endpointIdentifier: string;
  public defaultProtocol: string;
  public port: string;
  public host: string;
}
