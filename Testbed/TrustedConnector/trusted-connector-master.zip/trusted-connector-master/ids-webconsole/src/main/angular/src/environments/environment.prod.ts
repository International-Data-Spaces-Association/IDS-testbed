export const environment = {
  production: true,
  apiURL: './cxf/api/v1'
};
