/*
 * Copyright 2020 Fraunhofer Institute for Software and Systems Engineering
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.dataspaceconnector.services.ids;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.UUID;

import io.dataspaceconnector.model.AbstractEntity;
import io.dataspaceconnector.model.Artifact;
import io.dataspaceconnector.model.ArtifactDesc;
import io.dataspaceconnector.model.ArtifactFactory;
import io.dataspaceconnector.services.ids.builder.IdsArtifactBuilder;
import io.dataspaceconnector.utils.IdsUtils;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(classes = { ArtifactFactory.class, IdsArtifactBuilder.class})
public class IdsArtifactBuilderTest {

    @Autowired
    private ArtifactFactory artifactFactory;

    @Autowired
    private IdsArtifactBuilder idsArtifactBuilder;

    private final ZonedDateTime date = ZonedDateTime.now(ZoneOffset.UTC);

    @Test
    public void create_inputNull_throwNullPointerException() {
        /* ACT && ASSERT */
        assertThrows(NullPointerException.class, () -> idsArtifactBuilder.create(null));
    }

    @Test
    public void create_defaultDepth_returnCompleteArtifact() {
        /* ARRANGE */
        final var artifact = getArtifact();

        /* ACT */
        final var idsArtifact = idsArtifactBuilder.create(artifact);

        /* ASSERT */
        assertTrue(idsArtifact.getId().isAbsolute());
        assertTrue(idsArtifact.getId().toString().contains(artifact.getId().toString()));

        assertEquals(idsArtifact.getFileName(), artifact.getTitle());
        assertEquals(IdsUtils.getGregorianOf(artifact.getCreationDate()), idsArtifact.getCreationDate());
        assertNull(idsArtifact.getProperties());
    }

    @Test
    public void create_defaultDepthWithAdditional_returnCompleteArtifact() {
        /* ARRANGE */
        final var artifact = getArtifactWithAdditional();

        /* ACT */
        final var idsArtifact = idsArtifactBuilder.create(artifact);

        /* ASSERT */
        assertTrue(idsArtifact.getId().isAbsolute());
        assertTrue(idsArtifact.getId().toString().contains(artifact.getId().toString()));

        assertEquals(idsArtifact.getFileName(), artifact.getTitle());
        assertEquals(IdsUtils.getGregorianOf(artifact.getCreationDate()), idsArtifact.getCreationDate());

        assertNotNull(idsArtifact.getProperties());
        assertEquals(1, idsArtifact.getProperties().size());
        assertEquals("value", idsArtifact.getProperties().get("key"));
    }

    @Test
    public void create_maxDepth0_returnCompleteArtifact() {
        /* ARRANGE */
        final var artifact = getArtifact();

        /* ACT */
        final var idsArtifact = idsArtifactBuilder.create(artifact, 0);

        /* ASSERT */
        assertTrue(idsArtifact.getId().isAbsolute());
        assertTrue(idsArtifact.getId().toString().contains(artifact.getId().toString()));

        assertEquals(idsArtifact.getFileName(), artifact.getTitle());
        assertEquals(IdsUtils.getGregorianOf(artifact.getCreationDate()), idsArtifact.getCreationDate());
        assertNull(idsArtifact.getProperties());
    }

    @Test
    public void create_maxDepth5_returnCompleteArtifact() {
        /* ARRANGE */
        final var artifact = getArtifact();

        /* ACT */
        final var idsArtifact = idsArtifactBuilder.create(artifact, 5);

        /* ASSERT */
        assertTrue(idsArtifact.getId().isAbsolute());
        assertTrue(idsArtifact.getId().toString().contains(artifact.getId().toString()));

        assertEquals(idsArtifact.getFileName(), artifact.getTitle());
        assertEquals(IdsUtils.getGregorianOf(artifact.getCreationDate()), idsArtifact.getCreationDate());
        assertNull(idsArtifact.getProperties());
    }

    /**************************************************************************
     * Utilities.
     *************************************************************************/

    @SneakyThrows
    private Artifact getArtifact() {
        final var artifactDesc = new ArtifactDesc();
        artifactDesc.setTitle("title");
        artifactDesc.setAutomatedDownload(false);
        artifactDesc.setValue("value");
        final var artifact = artifactFactory.create(artifactDesc);

        final var idField = AbstractEntity.class.getDeclaredField("id");
        idField.setAccessible(true);
        idField.set(artifact, UUID.randomUUID());

        final var creationDateField = AbstractEntity.class.getDeclaredField("creationDate");
        creationDateField.setAccessible(true);
        creationDateField.set(artifact, date);

        return artifact;
    }

    @SneakyThrows
    private Artifact getArtifactWithAdditional() {
        final var artifact = getArtifact();
        final var additional = new HashMap<String, String>();
        additional.put("key", "value");

        final var additionalField = AbstractEntity.class.getDeclaredField("additional");
        additionalField.setAccessible(true);
        additionalField.set(artifact, additional);

        return artifact;
    }

}
