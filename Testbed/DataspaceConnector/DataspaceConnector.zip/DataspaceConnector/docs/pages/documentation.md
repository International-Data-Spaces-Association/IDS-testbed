---
layout: default
title: Documentation
nav_order: 7
description: ""
permalink: /Documentation
has_children: true
has_toc: true
---

# Software Documentation
{: .fs-9 }

For the developers, some software documentation is provided.
{: .fs-6 .fw-300 }

---

You might want to know more about the data model and the REST API or get an insight into the 
architecture of the Dataspace Connector. Have a look at the pages in this section. The documentation 
will be updated regularly.
